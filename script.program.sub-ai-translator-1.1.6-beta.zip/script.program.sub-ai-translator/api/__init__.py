from .mock import call as mock
from .openai import call as openai
from .gemini_api import call as gemini